Hamza Wasl — Parents App Icon Assets
Approved emblem: navy and gold portrait/logo.
Android: copy mipmap-*/ic_launcher.png and ic_launcher_round.png into android/app/src/main/res/ matching folders.
PWA: icon-192.png, icon-512.png.
Note: adaptive foreground layers not included; these are legacy and round launcher icons.
Only for app.hamzawasl.parents; no changes to admin/teacher apps.
