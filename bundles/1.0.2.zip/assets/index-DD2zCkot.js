const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BscAARmm.js","assets/index-BZ8Z5zQQ.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BZ8Z5zQQ.js";const o=r("Badge",{web:()=>t(()=>import("./web-BscAARmm.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
