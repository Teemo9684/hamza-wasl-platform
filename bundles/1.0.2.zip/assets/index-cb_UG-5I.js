const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-TntU2viw.js","assets/index-DGdJkScs.js","assets/index-0bWwPKOz.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-DGdJkScs.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-TntU2viw.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
