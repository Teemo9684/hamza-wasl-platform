const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BEIvGD1w.js","assets/index-BZ8Z5zQQ.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BZ8Z5zQQ.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BEIvGD1w.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
