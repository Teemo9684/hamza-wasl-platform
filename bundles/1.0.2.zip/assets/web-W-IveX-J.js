import{W as n}from"./index-BZ8Z5zQQ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
