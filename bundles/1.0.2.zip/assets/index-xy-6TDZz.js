const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-aAxUb-dr.js","assets/index-DGdJkScs.js","assets/index-0bWwPKOz.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DGdJkScs.js";const o=r("Badge",{web:()=>t(()=>import("./web-aAxUb-dr.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
