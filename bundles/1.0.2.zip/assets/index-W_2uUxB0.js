const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CBqKQBw2.js","assets/index-DGdJkScs.js","assets/index-0bWwPKOz.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DGdJkScs.js";const n=r("Preferences",{web:()=>t(()=>import("./web-CBqKQBw2.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
