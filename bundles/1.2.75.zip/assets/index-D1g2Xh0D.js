const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BiZH7MFP.js","assets/index-DS8zCNZd.js","assets/index-IQlwzBce.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-DS8zCNZd.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BiZH7MFP.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
