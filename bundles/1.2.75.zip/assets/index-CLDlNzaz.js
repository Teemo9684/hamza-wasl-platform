const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BUqZ9-WR.js","assets/index-DS8zCNZd.js","assets/index-IQlwzBce.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DS8zCNZd.js";const o=r("Badge",{web:()=>t(()=>import("./web-BUqZ9-WR.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
