const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-1-nMD-n7.js","assets/index-DS8zCNZd.js","assets/index-IQlwzBce.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DS8zCNZd.js";const n=r("Preferences",{web:()=>t(()=>import("./web-1-nMD-n7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
