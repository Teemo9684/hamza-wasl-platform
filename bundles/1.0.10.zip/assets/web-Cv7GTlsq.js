import{W as n}from"./index-BJYEDmXY.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
