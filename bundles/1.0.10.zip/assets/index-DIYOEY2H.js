const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DHT5tTAt.js","assets/index-BJYEDmXY.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BJYEDmXY.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DHT5tTAt.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
