const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-RA16illI.js","assets/index-BJYEDmXY.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BJYEDmXY.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-RA16illI.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
