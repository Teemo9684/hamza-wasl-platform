const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D0t7M5Y4.js","assets/index-O0LPUi5z.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-O0LPUi5z.js";const n=r("Preferences",{web:()=>t(()=>import("./web-D0t7M5Y4.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
