import{W as n}from"./index-O0LPUi5z.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
