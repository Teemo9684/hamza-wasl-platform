const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-6COeS-kY.js","assets/index-O0LPUi5z.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-O0LPUi5z.js";const o=r("Badge",{web:()=>t(()=>import("./web-6COeS-kY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
