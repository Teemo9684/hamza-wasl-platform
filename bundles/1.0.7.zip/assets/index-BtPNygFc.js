const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BAhXd-TP.js","assets/index-iwfJqRHv.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-iwfJqRHv.js";const n=r("Preferences",{web:()=>t(()=>import("./web-BAhXd-TP.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
