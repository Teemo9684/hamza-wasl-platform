const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BBp5bibm.js","assets/index-Cs8OVTa7.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cs8OVTa7.js";const n=r("Preferences",{web:()=>t(()=>import("./web-BBp5bibm.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
