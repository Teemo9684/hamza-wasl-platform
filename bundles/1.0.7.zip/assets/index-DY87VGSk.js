const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DOYRoFKS.js","assets/index-iwfJqRHv.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-iwfJqRHv.js";const o=r("Badge",{web:()=>t(()=>import("./web-DOYRoFKS.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
