import{W as n}from"./index-Cs8OVTa7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
