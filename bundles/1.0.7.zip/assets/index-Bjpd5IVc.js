const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DyhVkpPD.js","assets/index-Cs8OVTa7.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cs8OVTa7.js";const o=r("Badge",{web:()=>t(()=>import("./web-DyhVkpPD.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
