const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cl1vcQyp.js","assets/index-Cs8OVTa7.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-Cs8OVTa7.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-Cl1vcQyp.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
