const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dwgi-7ky.js","assets/index-aTeaqEO8.js","assets/index-fL_C1x1V.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-aTeaqEO8.js";const o=r("Badge",{web:()=>t(()=>import("./web-Dwgi-7ky.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
