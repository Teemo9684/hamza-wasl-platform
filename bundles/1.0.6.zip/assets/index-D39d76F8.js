const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BfdHUDTb.js","assets/index-CMtlG4tQ.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CMtlG4tQ.js";const o=r("Badge",{web:()=>t(()=>import("./web-BfdHUDTb.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
