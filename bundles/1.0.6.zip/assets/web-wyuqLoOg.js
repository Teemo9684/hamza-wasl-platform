import{W as n}from"./index-CMtlG4tQ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
