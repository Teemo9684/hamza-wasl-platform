const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CEhn9Izz.js","assets/index-D4bEx5wP.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-D4bEx5wP.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CEhn9Izz.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
