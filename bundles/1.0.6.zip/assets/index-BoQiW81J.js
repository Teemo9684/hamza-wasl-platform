const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DOhmYyE7.js","assets/index-D4bEx5wP.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D4bEx5wP.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DOhmYyE7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
