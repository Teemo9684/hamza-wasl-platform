const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CeOYX7KY.js","assets/index-CMtlG4tQ.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CMtlG4tQ.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CeOYX7KY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
