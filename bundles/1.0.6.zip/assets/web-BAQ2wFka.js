import{W as n}from"./index-D4bEx5wP.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
