const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DqntrxKV.js","assets/index-Co6j1KO7.js","assets/index-98F1_ECF.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Co6j1KO7.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DqntrxKV.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
