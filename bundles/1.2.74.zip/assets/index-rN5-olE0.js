const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C0Gw4mVG.js","assets/index-Co6j1KO7.js","assets/index-98F1_ECF.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Co6j1KO7.js";const o=r("Badge",{web:()=>t(()=>import("./web-C0Gw4mVG.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
