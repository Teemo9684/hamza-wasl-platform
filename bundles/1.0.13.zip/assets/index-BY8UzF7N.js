const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-lE_A5aOs.js","assets/index-C43PvPzg.js","assets/index-fL_C1x1V.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C43PvPzg.js";const o=r("Badge",{web:()=>t(()=>import("./web-lE_A5aOs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
