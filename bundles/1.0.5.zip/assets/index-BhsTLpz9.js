const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DlOmk2YY.js","assets/index-Cy2brKY2.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cy2brKY2.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DlOmk2YY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
