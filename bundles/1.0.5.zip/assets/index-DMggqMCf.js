const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-dmcstsci.js","assets/index-IWRPiapU.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-IWRPiapU.js";const n=r("Preferences",{web:()=>t(()=>import("./web-dmcstsci.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
