const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DsE2hz63.js","assets/index-rzhbKaQL.js","assets/index-BXilNiFV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-rzhbKaQL.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DsE2hz63.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
