const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D8jO8fhR.js","assets/index-BdIWUIDl.js","assets/index-BOqW-fjh.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BdIWUIDl.js";const o=r("Badge",{web:()=>t(()=>import("./web-D8jO8fhR.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
