const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DcTjXTa3.js","assets/index-CJj4ztQW.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CJj4ztQW.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DcTjXTa3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
