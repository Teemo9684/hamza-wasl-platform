const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BJ-heMNJ.js","assets/index-C7gNNvx4.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C7gNNvx4.js";const o=r("Badge",{web:()=>t(()=>import("./web-BJ-heMNJ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
