const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C9hGQJws.js","assets/index-CJj4ztQW.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CJj4ztQW.js";const n=r("Preferences",{web:()=>t(()=>import("./web-C9hGQJws.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
