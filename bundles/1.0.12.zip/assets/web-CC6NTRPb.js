import{W as n}from"./index-5Sr1VqcN.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
