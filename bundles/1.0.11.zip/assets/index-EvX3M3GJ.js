const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CUGMO2_0.js","assets/index-BPxidm9O.js","assets/index-BQD0jZSf.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BPxidm9O.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CUGMO2_0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
