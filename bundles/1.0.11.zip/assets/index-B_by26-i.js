const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CRdB5yQg.js","assets/index-BPxidm9O.js","assets/index-BQD0jZSf.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BPxidm9O.js";const n=r("Preferences",{web:()=>t(()=>import("./web-CRdB5yQg.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
