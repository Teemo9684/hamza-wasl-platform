const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CmbF-HJU.js","assets/index-BPxidm9O.js","assets/index-BQD0jZSf.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BPxidm9O.js";const o=r("Badge",{web:()=>t(()=>import("./web-CmbF-HJU.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
