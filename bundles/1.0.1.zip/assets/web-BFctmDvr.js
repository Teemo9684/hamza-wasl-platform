import{W as n}from"./index-DQZkC8Vj.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
