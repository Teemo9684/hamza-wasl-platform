const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cc5Vygjg.js","assets/index-BO7IN7c_.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BO7IN7c_.js";const o=r("Badge",{web:()=>t(()=>import("./web-Cc5Vygjg.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
