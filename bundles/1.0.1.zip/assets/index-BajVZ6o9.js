const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-kypXmRMH.js","assets/index-BO7IN7c_.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BO7IN7c_.js";const n=r("Preferences",{web:()=>t(()=>import("./web-kypXmRMH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
