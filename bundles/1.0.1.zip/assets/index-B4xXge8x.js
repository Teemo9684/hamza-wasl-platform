const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-M4dfowSD.js","assets/index-BO7IN7c_.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BO7IN7c_.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-M4dfowSD.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
