const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BnJT_pqa.js","assets/index-DQZkC8Vj.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DQZkC8Vj.js";const o=r("Badge",{web:()=>t(()=>import("./web-BnJT_pqa.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
