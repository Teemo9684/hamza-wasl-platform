import{W as n}from"./index-BO7IN7c_.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
