const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Ccoo-lKF.js","assets/index-DQZkC8Vj.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-DQZkC8Vj.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-Ccoo-lKF.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
