const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C4fItWhi.js","assets/index-CAYe8Lmf.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CAYe8Lmf.js";const o=r("Badge",{web:()=>t(()=>import("./web-C4fItWhi.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
