import{W as n}from"./index-CAYe8Lmf.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
