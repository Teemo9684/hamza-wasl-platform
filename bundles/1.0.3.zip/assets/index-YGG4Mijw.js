const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CiCkP7j0.js","assets/index-Cuhl7k-s.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-Cuhl7k-s.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CiCkP7j0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
