const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BiaclGU7.js","assets/index-CAYe8Lmf.js","assets/index-BbYkXtAW.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CAYe8Lmf.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BiaclGU7.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
