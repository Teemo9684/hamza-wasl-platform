const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DRVEH0i4.js","assets/index-Cuhl7k-s.js","assets/index-B4MW8rp6.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cuhl7k-s.js";const n=r("Preferences",{web:()=>t(()=>import("./web-DRVEH0i4.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
