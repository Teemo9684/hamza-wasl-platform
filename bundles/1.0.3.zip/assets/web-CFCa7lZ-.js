import{W as n}from"./index-Cuhl7k-s.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
