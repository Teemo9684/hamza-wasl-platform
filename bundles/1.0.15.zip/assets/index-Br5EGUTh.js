const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BnX2Swsc.js","assets/index-CeSIRojH.js","assets/index-fL_C1x1V.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CeSIRojH.js";const n=r("Preferences",{web:()=>t(()=>import("./web-BnX2Swsc.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
