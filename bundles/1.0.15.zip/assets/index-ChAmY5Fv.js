const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-kIrr9-uq.js","assets/index-CeSIRojH.js","assets/index-fL_C1x1V.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CeSIRojH.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-kIrr9-uq.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
