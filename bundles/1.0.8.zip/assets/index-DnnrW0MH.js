const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Ff4p9JvA.js","assets/index-C3kYj2vt.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C3kYj2vt.js";const n=r("Preferences",{web:()=>t(()=>import("./web-Ff4p9JvA.js"),__vite__mapDeps([0,1,2])).then(e=>new e.PreferencesWeb)});export{n as Preferences};
