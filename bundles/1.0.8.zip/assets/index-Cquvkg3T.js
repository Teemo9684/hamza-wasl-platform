const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CgCeTrcY.js","assets/index-C3kYj2vt.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C3kYj2vt.js";const o=r("Badge",{web:()=>t(()=>import("./web-CgCeTrcY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
