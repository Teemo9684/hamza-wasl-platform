import{W as n}from"./index-Cp7I7cfv.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
