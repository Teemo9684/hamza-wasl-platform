const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-ahVer9R9.js","assets/index-C3kYj2vt.js","assets/index-DQutL8E_.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-C3kYj2vt.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-ahVer9R9.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
