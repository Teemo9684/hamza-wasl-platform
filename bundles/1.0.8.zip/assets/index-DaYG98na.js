const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DkZDxaeN.js","assets/index-Cp7I7cfv.js","assets/index-B9TiGfmZ.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-Cp7I7cfv.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DkZDxaeN.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
